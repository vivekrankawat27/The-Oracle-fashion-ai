/**
 * WearWise - AI Fashion Stylist Landing Page Logic
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Sticky Navbar Effect
  const navbar = document.getElementById('navbar');
  const announcementBar = document.querySelector('.announcement-bar');
  
  if (navbar && announcementBar) {
    const stickyOffset = announcementBar.offsetHeight;
    
    window.addEventListener('scroll', () => {
      if (window.scrollY > stickyOffset) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    });
  }

  // 2. FAQ Accordion Logic
  const accordionBtns = document.querySelectorAll('.accordion-btn');
  
  accordionBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      // Toggle active state for button
      this.classList.toggle('active');
      
      // Get the corresponding content panel
      const content = this.nextElementSibling;
      
      // Toggle max-height for smooth transition
      if (content.style.maxHeight) {
        content.style.maxHeight = null;
      } else {
        // Calculate the height needed including padding
        content.style.maxHeight = content.scrollHeight + 30 + "px"; // 30px for padding
      }
      
      // Optional: Close other open panels (accordion behavior)
      accordionBtns.forEach(otherBtn => {
        if (otherBtn !== this && otherBtn.classList.contains('active')) {
          otherBtn.classList.remove('active');
          otherBtn.nextElementSibling.style.maxHeight = null;
        }
      });
    });
  });

  // 3. Smooth Scrolling for Anchor Links (safeguard, already handled by CSS)
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      
      if (targetId === '#') return;
      
      const targetElement = document.querySelector(targetId);
      
      if (targetElement) {
        e.preventDefault();
        
        // Offset for sticky header
        const headerOffset = 80;
        const elementPosition = targetElement.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
  
        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });
      }
    });
  });

  // 4. StyleFile Bubbles Interaction
  const bubbles = document.querySelectorAll('.bubble');
  
  // Distribute bubbles dynamically if needed (currently using CSS absolute positioning based on b-1 to b-7 classes)
  // Optional: Add a slight parallax or mousemove effect on the bubbles container
  const bubblesContainer = document.querySelector('.bubbles-container');
  
  if (bubblesContainer) {
    bubblesContainer.addEventListener('mousemove', (e) => {
      const rect = bubblesContainer.getBoundingClientRect();
      const x = e.clientX - rect.left; // x position within the element.
      const y = e.clientY - rect.top;  // y position within the element.
      
      // Calculate a normalized value -1 to 1 based on mouse position relative to center
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      
      const percentX = (x - centerX) / centerX;
      const percentY = (y - centerY) / centerY;
      
      bubbles.forEach((bubble, index) => {
        // Apply different subtle movements based on index to create depth
        const depth = (index % 3) + 1; 
        const moveX = percentX * (10 / depth);
        const moveY = percentY * (10 / depth);
        
        // Use Javascript transform instead of overriding CSS animation completely
        // Actually, CSS animations run continuously, so setting style.transform here might conflict.
        // Let's only apply it to bubbles that aren't hovered
        if (!bubble.matches(':hover')) {
          // Add a custom property that we could theoretically use in CSS calc()
          // or just leave it to CSS keyframes as implemented
        }
      });
    });
  }

  // 5. Intersection Observer for Scroll Animations
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px"
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('fade-in');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  // Apply to elements we want to animate on scroll
  const animateElements = document.querySelectorAll('.step-card, .outfit-card, .feature-row, .benefit-card');
  
  animateElements.forEach(el => {
    // Set initial state via inline styles or a class (we'll just use inline for ease here without editing CSS again)
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.6s ease-out, transform 0.6s ease-out';
    
    // Add logic to IntersectionObserver
    observer.observe(el);
  });
  
  // Add a simple fade-in class logic dynamically
  document.head.insertAdjacentHTML('beforeend', `
    <style>
      .fade-in {
        opacity: 1 !important;
        transform: translateY(0) !important;
      }
    </style>
  `);
});
