/**
 * Oracle VTO Engine v3 — CSS Two-Layer Fabric System
 *
 * Architecture:
 *   Layer 1 (.base-layer)     : User selfie image — fills the mirror frame
 *   Layer 2 (.overlay-layer)  : Garment PNG — absolutely positioned on top
 *
 * Controls:
 *   ▲▼◀▶  — move garment overlay (changes top/left %)
 *   ＋ / － — scale garment (changes width %)
 *   Drag   — drag the overlay with mouse/touch
 *
 * Save Look: merges both layers onto a hidden Canvas and downloads as PNG
 */

// ── Proxy strategies (in priority order) ─────────────────────────────
const VTO_PROXY_LOCAL     = 'http://localhost:7799/proxy?url=';
const VTO_PROXY_CORSPROXY = 'https://corsproxy.io/?';
const VTO_IMG_CACHE       = new Map(); // url → object-URL or data-url

// ── State ─────────────────────────────────────────────────────────────
let _vtoOverlayTop    = 35;   // % from top of mirror
let _vtoOverlayLeft   = 50;   // % from left of mirror  (centred)
let _vtoOverlayWidth  = 60;   // % of mirror width

// ── DOM helpers ────────────────────────────────────────────────────────
const $  = id => document.getElementById(id);
const log = msg => console.log(`[VTO] ${msg}`);

// ── Apply current overlay position/size to the DOM img ────────────────
function _applyOverlayStyle() {
  const g = $('vto-garment');
  if (!g) return;
  g.style.top       = `${_vtoOverlayTop}%`;
  g.style.left      = `${_vtoOverlayLeft}%`;
  g.style.width     = `${_vtoOverlayWidth}%`;
  g.style.transform = 'translate(-50%, -50%)';
}

// ── Load image through proxy chain ────────────────────────────────────
async function _loadViaProxy(url) {
  if (!url) return null;
  if (VTO_IMG_CACHE.has(url)) return VTO_IMG_CACHE.get(url);

  const strategies = [
    VTO_PROXY_LOCAL     + encodeURIComponent(url),
    VTO_PROXY_CORSPROXY + encodeURIComponent(url),
    url,   // direct (may fail CORS but worth trying for same-origin / CDN images)
  ];

  for (const proxyUrl of strategies) {
    try {
      const blob    = await _fetchBlob(proxyUrl);
      const objUrl  = URL.createObjectURL(blob);
      VTO_IMG_CACHE.set(url, objUrl);
      log(`Loaded via: ${proxyUrl.slice(0, 50)}…`);
      return objUrl;
    } catch (_) {}
  }
  log('All proxy strategies failed — garment image could not be loaded');
  return null;
}

function _fetchBlob(url) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', url);
    xhr.responseType = 'blob';
    xhr.timeout = 10000;
    xhr.onload  = () => xhr.status < 400 ? resolve(xhr.response) : reject(new Error(xhr.status));
    xhr.onerror = () => reject(new Error('network error'));
    xhr.ontimeout = () => reject(new Error('timeout'));
    xhr.send();
  });
}

// ── Pose-based initial positioning ────────────────────────────────────
// Simple heuristic: if we have pose keypoints stored, compute initial
// top/left/width from shoulder keypoints, otherwise use smart defaults.
function _computeInitialPlacement() {
  // Check if pose was detected (stored globally by pre-scan step)
  const kps = window._vtoLastPoseKeypoints; // set by pose detection pre-scan
  if (kps) {
    const ls = kps['leftShoulder'], rs = kps['rightShoulder'];
    const lh = kps['leftHip'],     rh = kps['rightHip'];

    const confOk = kp => kp && kp.score > 0.25;

    if (confOk(ls) && confOk(rs)) {
      // Shoulders give us horizontal centre and width
      const midX   = ((ls.x + rs.x) / 2) * 100; // normalised 0–100
      const width  = Math.abs(rs.x - ls.x) * 100 * 1.4 + 15; // 40% extra padding
      const top    = confOk(ls) ? ls.y * 100 - 5 : 35;

      _vtoOverlayLeft  = Math.max(20, Math.min(80, midX));
      _vtoOverlayTop   = Math.max(10, Math.min(70, top));
      _vtoOverlayWidth = Math.max(30, Math.min(90, width));
      return;
    }
  }
  // Default: torso-centred layout
  _vtoOverlayTop   = 35;
  _vtoOverlayLeft  = 50;
  _vtoOverlayWidth = 60;
}

// ── Drag support ──────────────────────────────────────────────────────
function _setupDrag() {
  const mirror  = $('virtual-mirror');
  const garment = $('vto-garment');
  if (!mirror || !garment) return;

  let dragging = false, startX, startY, startTop, startLeft;

  const px2pct = (px, dim) => (px / dim) * 100;

  garment.addEventListener('mousedown', e => {
    dragging = true;
    startX    = e.clientX;
    startY    = e.clientY;
    startTop  = _vtoOverlayTop;
    startLeft = _vtoOverlayLeft;
    e.preventDefault();
  });

  window.addEventListener('mousemove', e => {
    if (!dragging) return;
    const rect = mirror.getBoundingClientRect();
    _vtoOverlayLeft = startLeft + px2pct(e.clientX - startX, rect.width);
    _vtoOverlayTop  = startTop  + px2pct(e.clientY - startY, rect.height);
    _applyOverlayStyle();
  });

  window.addEventListener('mouseup', () => { dragging = false; });

  // Touch support
  garment.addEventListener('touchstart', e => {
    dragging = true;
    startX    = e.touches[0].clientX;
    startY    = e.touches[0].clientY;
    startTop  = _vtoOverlayTop;
    startLeft = _vtoOverlayLeft;
    e.preventDefault();
  }, { passive: false });

  window.addEventListener('touchmove', e => {
    if (!dragging) return;
    const rect = mirror.getBoundingClientRect();
    _vtoOverlayLeft = startLeft + px2pct(e.touches[0].clientX - startX, rect.width);
    _vtoOverlayTop  = startTop  + px2pct(e.touches[0].clientY - startY, rect.height);
    _applyOverlayStyle();
  });

  window.addEventListener('touchend', () => { dragging = false; });
}

// ── MAIN openVTO ──────────────────────────────────────────────────────
async function openVTO(btn) {
  const title  = btn?.dataset?.title  || 'Oracle Look';
  const imgUrl = btn?.dataset?.img    || '';
  const emoji  = btn?.dataset?.emoji  || '👗';

  // Reset state
  _vtoOverlayTop   = 35;
  _vtoOverlayLeft  = 50;
  _vtoOverlayWidth = 60;

  // Show modal
  $('vto-modal').classList.add('open');
  $('vto-item-label').textContent  = `Fitting: ${title.slice(0, 50)}`;
  $('vto-controls').style.display  = 'none';
  $('vto-save-btn').style.display  = 'none';
  $('vto-progress-wrap').style.display = 'block';

  const setP = (pct, msg) => {
    $('vto-fill').style.width     = pct + '%';
    $('vto-pct').textContent       = Math.round(pct) + '%';
    if (msg) $('vto-item-label').textContent = msg;
  };

  // ── Step 1: Selfie layer ───────────────────────────────────────────
  setP(15, 'Loading your selfie…');
  const selfieEl  = $('vto-selfie');
  const noSelfie  = $('vto-no-selfie');

  if (window.state?.imageBase64) {
    selfieEl.src          = 'data:image/jpeg;base64,' + state.imageBase64;
    selfieEl.style.display = 'block';
    noSelfie.style.display = 'none';
  } else {
    selfieEl.style.display = 'none';
    noSelfie.style.display = 'flex';
  }

  await _tick(100);

  // ── Step 2: Compute pose-based placement ──────────────────────────
  setP(35, 'Detecting body pose…');
  _computeInitialPlacement();
  await _tick(600); // let TF.js model warm up if it's doing work

  // ── Step 3: Load garment image via proxy ──────────────────────────
  setP(60, 'Fetching clothing image…');
  const garmentEl = $('vto-garment');

  if (imgUrl) {
    // Activate scan-line animation
    $('vto-scanline').classList.add('active');

    const resolvedUrl = await _loadViaProxy(imgUrl);
    $('vto-scanline').classList.remove('active');

    if (resolvedUrl) {
      garmentEl.src           = resolvedUrl;
      garmentEl.style.display = 'block';
      _applyOverlayStyle();
      _setupDrag();
      setP(90, 'Aligning garment to torso…');
      await _tick(500);
    } else {
      // Fallback: emoji indicator
      garmentEl.style.display = 'none';
      // Draw emoji in garment position via CSS pseudo or inline note
      toast('⚠', 'Image blocked by CDN. Try uploading the selfie first and the garment appears as overlay.');
    }
  } else {
    garmentEl.style.display = 'none';
  }

  // ── Step 4: Done ──────────────────────────────────────────────────
  setP(100, `Fitting: ${title.slice(0, 50)}`);
  await _tick(300);

  $('vto-progress-wrap').style.display = 'none';
  $('vto-controls').style.display      = (imgUrl ? 'block' : 'none');
  $('vto-save-btn').style.display      = 'inline-flex';

  if (imgUrl && garmentEl.src) {
    const hasSelfie = !!window.state?.imageBase64;
    toast('◈', hasSelfie
      ? 'Try-on ready! Drag the garment or use arrows to align it.'
      : 'Try-on ready! Upload a selfie for body layering.'
    );
  }
}

// ── Arrow control functions ────────────────────────────────────────────
function vtoAdjust(dx, dy) {
  _vtoOverlayLeft = Math.max(5,  Math.min(95,  _vtoOverlayLeft + dx));
  _vtoOverlayTop  = Math.max(-5, Math.min(110, _vtoOverlayTop  + dy));
  _applyOverlayStyle();
}

function vtoScale(delta) {
  _vtoOverlayWidth = Math.max(15, Math.min(110, _vtoOverlayWidth + delta));
  _applyOverlayStyle();
}

// ── Save Look — merges both layers on Canvas then downloads ───────────
function saveVTO() {
  const mirror   = $('virtual-mirror');
  const selfieEl = $('vto-selfie');
  const garment  = $('vto-garment');
  const canvas   = $('vto-canvas');

  if (!mirror) return;

  const mRect = mirror.getBoundingClientRect();
  const W = mRect.width  || 480;
  const H = mRect.height || 640;

  canvas.width  = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d');

  // Draw background
  if (selfieEl && selfieEl.src && selfieEl.style.display !== 'none') {
    ctx.drawImage(selfieEl, 0, 0, W, H);
  } else {
    // Dark gradient placeholder
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#0d0d1a');
    g.addColorStop(1, '#1a0e30');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
  }

  // Draw garment overlay
  if (garment && garment.src && garment.style.display !== 'none') {
    const gW = (W * _vtoOverlayWidth / 100);
    const gH = gW * (garment.naturalHeight / garment.naturalWidth || 1.4);
    const gX = (W * _vtoOverlayLeft  / 100) - gW / 2;
    const gY = (H * _vtoOverlayTop   / 100) - gH / 2;

    ctx.save();
    ctx.globalCompositeOperation = 'source-over';
    try {
      ctx.drawImage(garment, gX, gY, gW, gH);
    } catch (e) {
      // If canvas tainting occurs, skip garment layer
      log('Canvas taint error — garment not in Save Look: ' + e.message);
    }
    ctx.restore();
  }

  // Gold frame + label
  ctx.strokeStyle = 'rgba(212,175,55,0.55)';
  ctx.lineWidth   = 2;
  ctx.strokeRect(2, 2, W - 4, H - 4);
  ctx.fillStyle   = 'rgba(212,175,55,0.9)';
  ctx.font        = 'bold 11px Inter,sans-serif';
  ctx.textAlign   = 'left';
  ctx.fillText('◈ Oracle Virtual Mirror', 10, 18);

  // Download
  try {
    const a = document.createElement('a');
    a.href     = canvas.toDataURL('image/png');
    a.download = 'oracle-virtual-mirror.png';
    a.click();
    toast('✓', 'Look saved as oracle-virtual-mirror.png');
  } catch (e) {
    // CORS taint means we cannot export — use html screenshot fallback
    toast('⚠', 'Could not export (CORS taint). Screenshots via Ctrl+Shift+S instead.');
  }
}

// ── Close ─────────────────────────────────────────────────────────────
function closeVTO() {
  $('vto-modal').classList.remove('open');
}

// ── Helpers ───────────────────────────────────────────────────────────
function _tick(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// ── Register aliases for index.html shims ─────────────────────────────
window._vtoEngine_openVTO   = openVTO;
window._vtoEngine_closeVTO  = closeVTO;
window._vtoEngine_saveVTO   = saveVTO;
window._vtoEngine_vtoAdjust = vtoAdjust;
window._vtoEngine_vtoScale  = vtoScale;

// Also direct references
window.openVTO   = openVTO;
window.closeVTO  = closeVTO;
window.saveVTO   = saveVTO;
window.vtoAdjust = vtoAdjust;
window.vtoScale  = vtoScale;

log('VTO Engine v3 ready — CSS two-layer mode');
